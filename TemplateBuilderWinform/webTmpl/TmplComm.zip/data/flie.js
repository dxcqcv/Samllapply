﻿{
    "treebloom":"0",
    "items": [
				{ "id":1,"pid":-1, "text": "根目录", "value": "flie"},
				{ "id": 2, "pid": 1, "text": "ctrl", "value": "ctrl"},
				{ "id": 3, "pid": 1,"text": "data", "value": "data"},
				{ "id": 4, "pid": 1, "text": "libs", "value": "libs"},
				{ "id": 5, "pid": 1, "text": "model", "value": "model"},
				{ "id": 6, "pid": 1, "text": "view", "value": "view"},
				{ "id": 7, "pid": 1, "text": "tmpls", "value": "tmpls"},
				{ "id": 8, "pid": 7, "text": "项目模版一", "value": "tmpls"},
				{ "id": 9, "pid": 8, "text": "images", "value": "images"},
				{ "id": 10, "pid": 8, "text": "css", "value": "img"},
        { "id": 11, "pid": 1, "text": "templs.xml", "value": "templs"},
        { "id": 12, "pid": 2, "text": "ctrl.js", "value": "login"},
        { "id": 13, "pid": 3, "text": "data.js", "value": "main"},
        { "id": 14, "pid": 4, "text": "seeker.js", "value": "seeker"},
        { "id": 15, "pid": 4, "text": "ui", "value": "ui"},
        { "id": 16, "pid": 5, "text": "model.js", "value": "modelFlie"},
        { "id": 17, "pid": 6, "text": "view.js", "value": "viewFlie"},
        { "id": 18, "pid": 15, "text": "seeker.ui.xxx.js", "value": "seeker_ui_flie"},
        { "id": 19, "pid": 9, "text": "项目模版图片", "value": "img"},
        { "id": 20, "pid": 10, "text": "项目模版样式", "value": "csss"},
        { "id": 20, "pid": 8, "text": "main.html", "value": "main"}
			]
}