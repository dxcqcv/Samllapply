﻿{
		"treebloom":"0",
    "items": [
						{ "id":1,"pid":-1, "text": "帮助示例", "value": "bj"},
						{ "id": 2, "pid": 1, "text": "MVC编程帮助", "value": "scw"},
						{ "id": 3, "pid": 1,"text": "控件编程帮助", "value": "qzs"},
						{ "id": 4, "pid": 2, "text": "前端MVC编程示例", "value": "bc","grids":"2"},
						{ "id": 5, "pid": 3, "text": "dialog示例", "value": "cnjs","grids":"3" },
						{ "id": 6, "pid": 3, "text": "grid示例", "value": "zao" ,"grids":"4"}
			]
}